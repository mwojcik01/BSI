﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WCFBiblioteka.Klasy;

namespace WCFBiblioteka.Funkcje
{
    class static class FunkcjeStudenta
    {
        public static void DodajStudenta(string imie, string nazwisko, string indeks, string pesel, DateTime data_urodzenia, Plec plec,
            string ulica, string nr_domu, string nr_mieszkania, string miejscowosc, string kod_pocztowy, List<Student> lista_studentow)
        {

            Student student = new Student()
            {
                Imie = imie,
                Nazwisko = nazwisko,
                Indeks = indeks,
                Pesel = pesel,
                Data_urodzenia = data_urodzenia,
                Plec = plec
            };

            student.Adres.Ulica = ulica;
            student.Adres.NrDomu = nr_domu;
            student.Adres.NrMieszkania = nr_mieszkania;
            student.Adres.Miejscowosc = miejscowosc;
            student.Adres.Kod_Pocztowy = kod_pocztowy;

            lista_studentow.Add(student);
        }

        public static void UsunStudenta(string indeks, List<Student> lista_studentow) {
            lista_studentow.Remove(lista_studentow.FirstOrDefault(x => x.Indeks == indeks));
        }

        public static void EdytujStudenta(string indeks, List<Student> lista_studentow) {
            Student student = lista_studentow.FirstOrDefault(x => x.Indeks == indeks);

            if (student != null) {
                // .... edytujemy wartosci

            }

        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WCFBiblioteka.Klasy;
using WCFBiblioteka.Funkcje;

namespace WCFBiblioteka
{
    public class Service : IService
    {

        public void DodajStudenta(string imie, string nazwisko, string indeks, string pesel, DateTime data_urodzenia, Plec plec,
           string ulica, string nr_domu, string nr_mieszkania, string miejscowosc, string kod_pocztowy, List<Student> lista_studentow)
        {
            FunkcjeStudenta.DodajStudenta(imie, nazwisko, indeks, pesel, data_urodzenia, plec,
                ulica, nr_domu, nr_mieszkania, miejscowosc, kod_pocztowy, lista_studentow);
           
        }


        public void UsunStudenta(string indeks, List<Student> lista_studentow)
        {
            FunkcjeStudenta.UsunStudenta(indeks, lista_studentow);
        }

        public void EdytujStudenta(string indeks, List<Student> lista_studentow)
        {
            FunkcjeStudenta.EdytujStudenta(indeks, lista_studentow);

        }






    
           
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFBiblioteka.Klasy
{
    public class Student
    {
        string indeks;
        string pesel;
        string imie;
        string nazwisko;
        DateTime data_urodzenia;
        Plec plec;
        Adres adres;

        public string Indeks {
            get {
                return this.indeks;
            }

            set {
                if (this.indeks != value)
                    this.indeks = value;
            }
        }

        public string Pesel
        {
            get
            {
                return this.pesel;
            }

            set
            {
                if (this.pesel != value)
                    this.pesel = value;
            }
        }


        public string Imie
        {
            get
            {
                return this.imie;
            }

            set
            {
                if (this.imie != value)
                    this.imie = value;
            }
        }


        public string Nazwisko
        {
            get
            {
                return this.nazwisko;
            }

            set
            {
                if (this.nazwisko != value)
                    this.nazwisko = value;
            }
        }


        public DateTime Data_urodzenia
        {
            get
            {
                return this.data_urodzenia;
            }

            set
            {
                if (this.data_urodzenia != value)
                    this.data_urodzenia = value;
            }
        }
        public Plec Plec
        {
            get
            {
                return this.plec;
            }

            set
            {
                if (this.plec != value)
                    this.plec = value;
            }
        }
        public Adres Adres
        {
            get
            {
                return this.adres;
            }

            set
            {
                if (this.adres != value)
                    this.adres = value;
            }
        }

      



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFBiblioteka.Klasy
{
    public class Adres
    {
        string ulica;
        string nrDomu;
        string nrMieszkania;
        string kod_Pocztowy;
        string miejscowosc;


        public string Ulica
        {
            get
            {
                return this.ulica;
            }

            set
            {
                if (this.ulica != value)
                    this.ulica = value;
            }
        }
        public string NrDomu
        {
            get
            {
                return this.nrDomu;
            }

            set
            {
                if (this.nrDomu != value)
                    this.nrDomu = value;
            }
        }
        public string NrMieszkania
        {
            get
            {
                return this.nrMieszkania;
            }

            set
            {
                if (this.nrMieszkania != value)
                    this.nrMieszkania = value;
            }
        }
        public string Kod_Pocztowy
        {
            get
            {
                return this.kod_Pocztowy;
            }

            set
            {
                if (this.kod_Pocztowy != value)
                    this.kod_Pocztowy = value;
            }
        }

        public string Miejscowosc
        {
            get
            {
                return this.miejscowosc;
            }

            set
            {
                if (this.miejscowosc != value)
                    this.miejscowosc = value;
            }
        }

        public override string ToString()
        {
            return String.Format("Ulica: {0} {1} m. {2}\n{3} {4} ", Ulica, NrDomu, NrMieszkania, Kod_Pocztowy, Miejscowosc);
        }



    }
}

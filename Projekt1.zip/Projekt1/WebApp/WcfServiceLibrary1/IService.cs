﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WCFBiblioteka.Klasy;


namespace WCFBiblioteka
{
   
    [ServiceContract]
    public interface IService
    {
        [OperationContract]

        void DodajStudenta(string imie, string nazwisko, string indeks, string pesel, DateTime data_urodzenia, Plec plec,
           string ulica, string nr_domu, string nr_mieszkania, string miejscowosc, string kod_pocztowy, List<Student> lista_studentow);

        void UsunStudenta(string indeks, List<Student> lista_studentow);
        void EdytujStudenta(string indeks, List<Student> lista_studentow);

    }

   
}
